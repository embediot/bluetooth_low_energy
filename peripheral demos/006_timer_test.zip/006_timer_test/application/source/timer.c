#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrf_drv_timer.h"
#include "timer.h"
#include "led_gpio.h"

#if (CURRENT_TEST_FUNC == TIMER_TEST)

const nrf_drv_timer_t my_timer = NRF_DRV_TIMER_INSTANCE(0);

static void my_timer_event_handler(nrf_timer_event_t event_type, void* p_context)
{
    static unsigned int count = 0;
    switch (event_type)
    {
        case NRF_TIMER_EVENT_COMPARE0:
        {           
            NRF_LOG_INFO(">>> my_timer_event_handler, NRF_TIMER_EVENT_COMPARE0, count = %d >>> ",count++);           
        }break;

        case NRF_TIMER_EVENT_COMPARE1:
        {
            NRF_LOG_INFO(">>> my_timer_event_handler, NRF_TIMER_EVENT_COMPARE1, count = %d >>> ",count++);
        }break;

        case NRF_TIMER_EVENT_COMPARE2:
        {
            NRF_LOG_INFO(">>> my_timer_event_handler, NRF_TIMER_EVENT_COMPARE2, count = %d >>> ",count++);
        }break;

        case NRF_TIMER_EVENT_COMPARE3:
        {
            NRF_LOG_INFO(">>> my_timer_event_handler, NRF_TIMER_EVENT_COMPARE3, count = %d >>> ",count++);
        }break;
        default:break;
    }
}

void my_timer_init(void)
{
    unsigned int timeout_ms = 1000;
    unsigned int timerout_ticks = 0;
    unsigned int err_code = NRF_SUCCESS;

    nrf_drv_timer_config_t timer_cfg = NRF_DRV_TIMER_DEFAULT_CONFIG;

    timer_cfg.frequency = NRF_TIMER_FREQ_16MHz;

    err_code = nrf_drv_timer_init(&my_timer, &timer_cfg, my_timer_event_handler);

    APP_ERROR_CHECK(err_code);

    timerout_ticks = nrf_drv_timer_ms_to_ticks(&my_timer, timeout_ms);

    NRF_LOG_INFO(">>> my_timer_init, timerout_ticks = %d >>> ",timerout_ticks);

    nrf_drv_timer_extended_compare(&my_timer, NRF_TIMER_CC_CHANNEL0, timerout_ticks, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);
}

void my_timer_start(void)
{
    nrf_drv_timer_enable(&my_timer);
}

void my_timer_stop(void)
{
    nrf_drv_timer_disable(&my_timer);
}

#elif (CURRENT_TEST_FUNC == COUNTER_TEST)

const nrf_drv_timer_t my_timer = NRF_DRV_TIMER_INSTANCE(0);

static void my_timer_event_handler(nrf_timer_event_t event_type, void* p_context)
{
    
}

void my_timer_init(void)
{
    unsigned int err_code = NRF_SUCCESS;

    nrf_drv_timer_config_t timer_cfg = NRF_DRV_TIMER_DEFAULT_CONFIG;

    timer_cfg.frequency = NRF_TIMER_FREQ_16MHz;
    timer_cfg.mode = NRF_TIMER_MODE_COUNTER;

    err_code = nrf_drv_timer_init(&my_timer, &timer_cfg, my_timer_event_handler);

    APP_ERROR_CHECK(err_code);
}

void my_timer_start(void)
{
    nrf_drv_timer_enable(&my_timer);
}

void my_timer_stop(void)
{
    nrf_drv_timer_disable(&my_timer);
}

void my_timer_increment(void)
{
    nrfx_timer_increment(&my_timer);
}

unsigned int my_timer_capture(void)
{
    unsigned int counter_value = 0;

    counter_value = nrfx_timer_capture(&my_timer,NRF_TIMER_CC_CHANNEL2);

    return counter_value;
}

#endif

