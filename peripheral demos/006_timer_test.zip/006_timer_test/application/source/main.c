#include <stdbool.h>
#include <stdint.h>
#include "nrf_delay.h"
#include "led_gpio.h"
#include "gpiote.h"
#include "uarte.h"
#include "log_debug.h"
#include "timer.h"

int main(void)
{
    static unsigned int count = 0;

    log_debug_init();  
    leds_gpio_init();
    my_gpiote_init();
    my_timer_init();
    my_timer_start();

    LOG_OUTPUT(">>> timer test example started >>> %s >>>", "helloworld");
   
    while (true)
    {
        #if (CURRENT_TEST_FUNC == COUNTER_TEST)
            count = my_timer_capture();
            LOG_OUTPUT(">>> timer counter value = %d >>>", count);
            nrf_delay_ms(2000);
        #endif
    }
}
