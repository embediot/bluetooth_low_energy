#include "button_gpio.h"
#include <stdbool.h>
#include <stdint.h>


static uint8_t m_button_list[BUTTONS_NUMBER] = BUTTONS_LIST;

bool get_button_state(uint32_t button_index)
{
    ASSERT(button_index < BUTTONS_NUMBER);

    bool pin_set = nrf_gpio_pin_read(m_button_list[button_index]) ? true : false;

    return (pin_set == (BUTTONS_ACTIVE_STATE ? true : false));
}

void buttons_gpio_init(void)
{
    uint32_t i;

    for (i = 0; i < BUTTONS_NUMBER; ++i)
    {
        nrf_gpio_cfg_input(m_button_list[i], BUTTON_PULL);
    }
}



