#include "nrf_gpiote.h"
#include "nrf_gpio.h"
#include "nrf_drv_gpiote.h"
#include "nrf_delay.h"
#include "gpiote.h"
#include "led_gpio.h"
#include "button_gpio.h"
#include "log_debug.h"

#if (CURRENT_TEST == GPIOTE_TASK_OUTPUT)
void gpiote_task_test()
{
    #if (!defined(GPIOTE_TASK_GPIO_OUTPUT))  //use GPIOTE TASK MODULE OUTPUT
        nrf_drv_gpiote_out_task_trigger(LED_1);
        nrf_drv_gpiote_out_task_trigger(LED_2);
        nrf_drv_gpiote_out_task_trigger(LED_3);
        nrf_drv_gpiote_out_task_trigger(LED_4);
        nrf_delay_ms(100);
    #else
        nrfx_gpiote_out_set(LED_1);
        nrfx_gpiote_out_set(LED_2);
        nrfx_gpiote_out_set(LED_3);
        nrfx_gpiote_out_set(LED_4);
        nrf_delay_ms(1000);
        nrfx_gpiote_out_clear(LED_1);
        nrfx_gpiote_out_clear(LED_2);
        nrfx_gpiote_out_clear(LED_3);
        nrfx_gpiote_out_clear(LED_4);
        nrf_delay_ms(1000);
    #endif
}

void my_gpiote_init(void)
{
    ret_code_t err_code;

    err_code = nrf_drv_gpiote_init();
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_out_config_t out_config = GPIOTE_CONFIG_OUT_TASK_TOGGLE(true);  

    err_code = nrf_drv_gpiote_out_init(LED_1, &out_config);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_out_init(LED_2, &out_config);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_out_init(LED_3, &out_config);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_out_init(LED_4, &out_config);
    APP_ERROR_CHECK(err_code);

    #if (!defined(GPIOTE_TASK_GPIO_OUTPUT)) 
        nrf_drv_gpiote_out_task_enable(LED_1);
        nrf_drv_gpiote_out_task_enable(LED_2);
        nrf_drv_gpiote_out_task_enable(LED_3);
        nrf_drv_gpiote_out_task_enable(LED_4);
    #endif
}

#elif (CURRENT_TEST == GPIOTE_EVENT_INPUT)

static void in_pin_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
    if(pin == BUTTON_1)
    {
        nrf_drv_gpiote_out_toggle(LED_1);
        nrf_drv_gpiote_out_toggle(LED_2);
        nrf_drv_gpiote_out_toggle(LED_3);
        nrf_drv_gpiote_out_toggle(LED_4);
    }
}

void my_gpiote_init(void)
{
    ret_code_t err_code;

    err_code = nrf_drv_gpiote_init();
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_out_config_t out_config = GPIOTE_CONFIG_OUT_SIMPLE(false);

    err_code = nrf_drv_gpiote_out_init(LED_1, &out_config);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_out_init(LED_2, &out_config);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_out_init(LED_3, &out_config);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_out_init(LED_4, &out_config);
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_in_config_t in_config = GPIOTE_CONFIG_IN_SENSE_LOTOHI(true);
    in_config.pull = NRF_GPIO_PIN_PULLUP;

    err_code = nrf_drv_gpiote_in_init(BUTTON_1, &in_config, in_pin_handler);
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_in_event_enable(BUTTON_1, true);
}

#elif (CURRENT_TEST == GPIOTE_PORT_INPUT)

static void in_pin_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
    if(pin == BUTTON_1)
    {
        nrf_gpio_pin_toggle(LED_1);
        LOG_OUTPUT(">>> button 1 clicked >>>");
    }
    else if(pin == BUTTON_2)
    {
        nrf_gpio_pin_toggle(LED_2);
        LOG_OUTPUT(">>> button 2 clicked >>>");
    }
    else if(pin == BUTTON_3)
    {
        nrf_gpio_pin_toggle(LED_3);
        LOG_OUTPUT(">>> button 3 clicked >>>");
    }
    else if(pin == BUTTON_4)
    {
        nrf_gpio_pin_toggle(LED_4);
        LOG_OUTPUT(">>> button 4 clicked >>>");
    }
    else{}
}

void my_gpiote_init(void)
{
    ret_code_t err_code;

    err_code = nrf_drv_gpiote_init();
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_in_config_t in_config = GPIOTE_CONFIG_IN_SENSE_HITOLO(false);
    in_config.pull = NRF_GPIO_PIN_PULLUP;

    err_code = nrf_drv_gpiote_in_init(BUTTON_1, &in_config, in_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(BUTTON_2, &in_config, in_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(BUTTON_3, &in_config, in_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(BUTTON_4, &in_config, in_pin_handler);
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_in_event_enable(BUTTON_1, true);
    nrf_drv_gpiote_in_event_enable(BUTTON_2, true);
    nrf_drv_gpiote_in_event_enable(BUTTON_3, true);
    nrf_drv_gpiote_in_event_enable(BUTTON_4, true);
}
#endif


