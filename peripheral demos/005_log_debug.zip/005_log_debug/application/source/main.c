#include <stdbool.h>
#include <stdint.h>
#include "nrf_delay.h"
#include "led_gpio.h"
#include "gpiote.h"
#include "uarte.h"
#include "log_debug.h"

int main(void)
{
    leds_gpio_init();
    my_gpiote_init();
    my_uart_init();
    log_debug_init();    

    LOG_OUTPUT(">>> log debug example started >>> %s >>>", "helloworld");

    while (true)
    {
        #if (CURRENT_TEST == GPIOTE_TASK_OUTPUT)
            gpiote_task_test();
        #elif (CURRENT_TEST == GPIOTE_EVENT_INPUT)

        #elif (CURRENT_TEST == GPIOTE_PORT_INPUT)

        #endif
    }
}


