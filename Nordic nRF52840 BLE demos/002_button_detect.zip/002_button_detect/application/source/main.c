#include <stdbool.h>
#include <stdint.h>
#include "nrf_delay.h"
#include "led_gpio.h"
#include "button_gpio.h"

int main(void)
{
    leds_gpio_init();
    buttons_gpio_init();

    while (true)
    {
        if(get_button_state(0)){
            nrf_delay_ms(200);
            if(get_button_state(0))set_led_toggle(0);
        }

        if(get_button_state(1)){
            nrf_delay_ms(200);
            if(get_button_state(1))set_led_toggle(1);
        }

        if(get_button_state(2)){
            nrf_delay_ms(200);
            if(get_button_state(2))set_led_toggle(2);
        }

        if(get_button_state(3)){
            nrf_delay_ms(200);
            if(get_button_state(3))set_led_toggle(3);
        }
    }
}


