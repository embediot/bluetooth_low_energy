#include <stdbool.h>
#include <stdint.h>
#include "nrf_delay.h"
#include "led_gpio.h"
#include "gpiote.h"

int main(void)
{
    leds_gpio_init();
    my_gpiote_init();

    while (true)
    {
        #if (CURRENT_TEST == GPIOTE_TASK_OUTPUT)
            gpiote_task_test();
        #elif (CURRENT_TEST == GPIOTE_EVENT_INPUT)

        #elif (CURRENT_TEST == GPIOTE_PORT_INPUT)

        #endif
    }
}


