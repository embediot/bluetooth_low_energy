#include "led_gpio.h"
#include <stdbool.h>
#include <stdint.h>

static uint8_t m_led_list[LEDS_NUMBER] = LEDS_LIST;

void set_led_off(uint32_t led_index) {
  ASSERT(led_index < LEDS_NUMBER);
  nrf_gpio_pin_write(m_led_list[led_index], LEDS_ACTIVE_STATE ? 0 : 1);
}

void set_led_on(uint32_t led_index) {
  ASSERT(led_index < LEDS_NUMBER);
  nrf_gpio_pin_write(m_led_list[led_index], LEDS_ACTIVE_STATE ? 1 : 0);
}

void set_led_toggle(uint32_t led_index) {
  ASSERT(led_index < LEDS_NUMBER);
  nrf_gpio_pin_toggle(m_led_list[led_index]);
}

void set_all_leds_off(void) {
  uint32_t i;
  for (i = 0; i < LEDS_NUMBER; ++i) {
    set_led_off(i);
  }
}

void set_all_leds_on(void) {
  uint32_t i;
  for (i = 0; i < LEDS_NUMBER; ++i) {
    set_led_on(i);
  }
}

void set_all_leds_toggle(void) {
  uint32_t i;
  for (i = 0; i < LEDS_NUMBER; ++i) {
    set_led_toggle(i);
  }
}

void leds_gpio_init(void) {
  uint32_t i;
  for (i = 0; i < LEDS_NUMBER; ++i) {
    nrf_gpio_cfg_output(m_led_list[i]);
  }
}