#ifndef _UARTE_H_
#define _UARTE_H_

#include "nrf_gpio.h"
#include "nordic_common.h"

#define RX_PIN_NUMBER          NRF_GPIO_PIN_MAP(0,8)
#define TX_PIN_NUMBER          NRF_GPIO_PIN_MAP(0,6)
#define CTS_PIN_NUMBER         NRF_GPIO_PIN_MAP(0,7)
#define RTS_PIN_NUMBER         NRF_GPIO_PIN_MAP(0,5)

#define UART_TX_BUF_SIZE       256                        
#define UART_RX_BUF_SIZE       256                        

#define UART_HWFC              APP_UART_FLOW_CONTROL_DISABLED

extern void my_uart_init(void);

#endif

