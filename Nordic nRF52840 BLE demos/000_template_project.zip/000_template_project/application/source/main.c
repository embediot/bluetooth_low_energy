#include <stdint.h>
#include <string.h>







int main(void)
{
    
    return 0;
}


