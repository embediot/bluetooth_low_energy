#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "nrf_uart.h"
#include "nrf_uarte.h"
#include "app_uart.h"
#include "app_error.h"
#include "uarte.h"

static void uart_event_handler(app_uart_evt_t * p_event)
{
    switch(p_event->evt_type)
    {
        /*An event indicating that UART data has been received. The data is available in the FIFO and can be fetched using @ref app_uart_get*/
        case APP_UART_DATA_READY:
        {
            uint8_t cr;
            while (app_uart_get(&cr) != NRF_SUCCESS);while (app_uart_put(cr) != NRF_SUCCESS);
        }
        break;

        /*An error in the FIFO module used by the app_uart module has occured. The FIFO error code is stored in app_uart_evt_t.data.error_code field*/
        case APP_UART_FIFO_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_code);
        break;

        /*An communication error has occured during reception. The error is stored in app_uart_evt_t.data.error_communication field */
        case APP_UART_COMMUNICATION_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_communication);
        break;

        /*An event indicating that UART has completed transmission of all available data in the TX FIFO */
        case APP_UART_TX_EMPTY:
        break;

        /*An event indicating that UART data has been received, and data is present in data field. This event is only used when no FIFO is configured */
        case APP_UART_DATA:
        break;
        
        default:break;
    }
}

void my_uart_init(void)
{
    uint32_t err_code;

    const app_uart_comm_params_t comm_params = {
          RX_PIN_NUMBER,TX_PIN_NUMBER,
          RTS_PIN_NUMBER,CTS_PIN_NUMBER,
          UART_HWFC,false,NRF_UARTE_BAUDRATE_115200
      };

    APP_UART_FIFO_INIT(&comm_params,UART_RX_BUF_SIZE,UART_TX_BUF_SIZE, \
                         uart_event_handler,APP_IRQ_PRIORITY_LOWEST,err_code);

    APP_ERROR_CHECK(err_code);
}

