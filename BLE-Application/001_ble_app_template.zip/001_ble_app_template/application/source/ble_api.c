#include "ble_api.h"
#include "app_timer.h"
#include "app_error.h"
#include "bsp.h"
#include "log_debug.h"

#include "ble_advdata.h"
#include "ble_advertising.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_sdh.h"
#include "nrf_sdh_soc.h"
#include "nrf_sdh_ble.h"
#include "nrf_ble_qwr.h"
#include "nrf_ble_gatt.h"
#include "ble_conn_params.h"


NRF_BLE_GATT_DEF(m_gatt);               //GATT模块实例
NRF_BLE_QWR_DEF(m_qwr);                 //QWR队列实例
BLE_ADVERTISING_DEF(m_advertising);     //广播模块实例

//蓝牙连接句柄，用来保存从机的连接
static unsigned short m_conn_handle = BLE_CONN_HANDLE_INVALID;     



static void timers_init(void);
static void leds_init(void);
static void power_management_init(void);
static void ble_stack_init(void);
static void gap_params_init(void);
static void gatt_init(void);
static void advertising_init(void);
static void conn_params_init(void);
static void advertising_start(void);

//初始化定时器模块
static void timers_init(void)
{
    ret_code_t err_code;
    
    err_code = app_timer_init();   

    APP_ERROR_CHECK(err_code);
}

//初始化开发板的指示灯
static void leds_init(void)
{
    ret_code_t err_code;
    
    err_code = bsp_init(BSP_INIT_LEDS,NULL); 

    APP_ERROR_CHECK(err_code);
}

//初始化电源管理
static void power_management_init(void)
{
    ret_code_t err_code;

    err_code = nrf_pwr_mgmt_init();  

    APP_ERROR_CHECK(err_code);
}

//BLE事件处理函数
static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
    ret_code_t err_code = NRF_SUCCESS;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_DISCONNECTED:      //连接断开事件
            LOG_OUTPUT("Disconnected.");
        break;

        case BLE_GAP_EVT_CONNECTED:         //连接成功事件
            LOG_OUTPUT("Connected.");
            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);

            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
       
            err_code = nrf_ble_qwr_conn_handle_assign(&m_qwr, m_conn_handle);  //把连接句柄写入队列
            APP_ERROR_CHECK(err_code);
        break;

        case BLE_GAP_EVT_PHY_UPDATE_REQUEST:   //物理层更新事件
        {
            LOG_OUTPUT("PHY update request.");
            ble_gap_phys_t const phys =
            {
                .rx_phys = BLE_GAP_PHY_AUTO,
                .tx_phys = BLE_GAP_PHY_AUTO,
            };

            err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
            APP_ERROR_CHECK(err_code);
        } break;

        case BLE_GATTC_EVT_TIMEOUT:      //GATT客户端超时事件
            LOG_OUTPUT("GATT Client Timeout.");

            //断开当前连接
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle,
            BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
        break;

        case BLE_GATTS_EVT_TIMEOUT:     //GATT服务器超时事件
            LOG_OUTPUT("GATT Server Timeout.");

            //断开当前连接
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle,
            BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
        break;

        default:
        break;
    }
}

//BLE协议栈初始化
static void ble_stack_init(void)
{
    ret_code_t err_code;

    if(!nrf_sdh_is_enabled())    //如果还没有使能协议栈
    {
        //请求使能协议栈，并在这个函数里面初始化时钟
        err_code = nrf_sdh_enable_request();
        APP_ERROR_CHECK(err_code);
    }

    //使用默认参数配置协议栈，并且把内存的起始地址告诉协议栈
    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);

    //使能协议栈
    err_code = nrf_sdh_ble_enable(&ram_start);
    APP_ERROR_CHECK(err_code);

    //注册协议栈事件的回调函数
    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}

//GAP参数配置，包括设备名称，外观特征参数，首选连接参数
static void gap_params_init(void)
{
    ret_code_t err_code;

    ble_gap_conn_params_t   gap_conn_params;   //连接参数
    ble_gap_conn_sec_mode_t sec_mode;           //安全模式

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);     //设置为开放连接模式

    err_code = sd_ble_gap_device_name_set(&sec_mode,(const uint8_t *)DEVICE_NAME,strlen(DEVICE_NAME));   //设置设备名称
    APP_ERROR_CHECK(err_code);

    /*设置首选连接参数*/
    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;   
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);  //把参数写入协议栈
    APP_ERROR_CHECK(err_code);
    
}

//初始化   GATT模块
static void gatt_init(void)
{
    ret_code_t err_code;

    err_code = nrf_ble_gatt_init(&m_gatt, NULL);

    APP_ERROR_CHECK(err_code);
}

//广播事件处理函数
static void on_adv_evt(ble_adv_evt_t ble_adv_evt)
{
    ret_code_t err_code;

    switch(ble_adv_evt)
    {
        case BLE_ADV_EVT_FAST:    //快速广播事件
            LOG_OUTPUT("Fast advertising.");
            err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
            APP_ERROR_CHECK(err_code);
        break;

        case BLE_ADV_EVT_IDLE:    //快速广播超时事件
            LOG_OUTPUT("Fast advertising timeout");
            err_code = bsp_indication_set(BSP_INDICATE_IDLE);
            APP_ERROR_CHECK(err_code);
        break;

        default:
        break; 
    }
}

//广播初始化
static void advertising_init(void)
{
    ret_code_t err_code;
    ble_advertising_init_t init;

    memset(&init, 0, sizeof(init));   //先清零广播配置参数

    init.advdata.name_type               = BLE_ADVDATA_FULL_NAME;     //全名称广播
    init.advdata.include_appearance      = true;                      //包含广播外观值
    init.advdata.flags                   = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;   //一般可发现模式
    init.config.ble_adv_fast_enabled     = true;     //设置为快速广播
    init.config.ble_adv_fast_interval    = ADV_FAST_INTERVAL;     //快速广播的间隔
    init.config.ble_adv_fast_timeout     = ADV_FAST_DURATION;     //快速广播的持续时间
    init.evt_handler = on_adv_evt;        //广播事件的回调函数

    err_code = ble_advertising_init(&m_advertising, &init);    //根据参数初始化广播
    APP_ERROR_CHECK(err_code);

    ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);  //配置广播标记，默认数值为1
}

//QWR队列事件错误处理
static void nrf_qwr_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}

//服务初始化函数
static void services_init(void)
{
    ret_code_t         err_code;

    //初始化队列写入模块
    nrf_ble_qwr_init_t qwr_init = {0};

    qwr_init.error_handler = nrf_qwr_error_handler;
    err_code = nrf_ble_qwr_init(&m_qwr, &qwr_init);
    APP_ERROR_CHECK(err_code);

    //以后可以在这个函数里面添加服务
    //目前工程模板只有两个强制包含的服务
    //GAP and GATT 
}

//连接参数协商事件处理函数
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    ret_code_t err_code;

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)    //连接参数协商失败，断开连接
    {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_SUCCEEDED)    //连接参数协商成功
    {

    }
}

//连接参数协商错误
static void conn_params_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}

//连接参数协商初始化
static void conn_params_init(void)
{
    ret_code_t             err_code;
    ble_conn_params_init_t cp_init;

    memset(&cp_init, 0, sizeof(cp_init));    //先清空配置参数

    cp_init.p_conn_params                  = NULL;       //设置为   NULL，表示从主机那里获取连接参数
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;     //首次连接参数更新的延时时间
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;      //以后每次连接参数更新的时间
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;       //尝试连接参数协商的最大次数，超过此次数就放弃连接参数协商
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;            //从连接事件开始计时
    cp_init.disconnect_on_fail             = false;                              //参数更新失败的时候，不会断开蓝牙连接
    cp_init.evt_handler                    = on_conn_params_evt;                 //连接参数更新事件
    cp_init.error_handler                  = conn_params_error_handler;          //连接参数更新错误事件

    err_code = ble_conn_params_init(&cp_init);              //初始化连接参数更新的模块
    APP_ERROR_CHECK(err_code);
}

//启动广播
static void advertising_start(void)
{
    ret_code_t err_code;

    err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);

    APP_ERROR_CHECK(err_code);
}



//BLE相关接口函数初始化
void ble_api_init(void)
{
    timers_init();                    //定时器初始化

    leds_init();                      //指示灯初始化

    power_management_init();          //电源管理初始化

    ble_stack_init();                 //BLE协议栈初始化
 
    gap_params_init();                //GAP参数初始化

    gatt_init();                      //GATT服务初始化

    advertising_init();               //广播初始化

    services_init();                  //BLE服务初始化

    conn_params_init();               //蓝牙连接参数初始化

    advertising_start();              //启动广播
}

