#include "ble_api.h"
#include "app_timer.h"
#include "app_error.h"
#include "bsp.h"
#include "log_debug.h"

#include "ble_advdata.h"
#include "ble_advertising.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_sdh.h"
#include "nrf_sdh_soc.h"
#include "nrf_sdh_ble.h"
#include "nrf_ble_qwr.h"
#include "nrf_ble_gatt.h"
#include "ble_conn_params.h"

#include "app_timer.h"
#include "my_ble_uart.h"
#include "uarte.h"
#include "app_uart.h"


NRF_BLE_GATT_DEF(m_gatt);               //GATT模块实例
NRF_BLE_QWR_DEF(m_qwr);                 //QWR队列实例
BLE_ADVERTISING_DEF(m_advertising);     //广播模块实例

BLE_UART_DEF(m_uart);                 //串口透传服务实例

#define HEART_RATE_INTERVAL             APP_TIMER_TICKS(1000)   //用于心率测量的APP定时器
#define SENSOR_CONTACT_UPDATE_INTERVAL  APP_TIMER_TICKS(5000)   //用于接触状态更新的APP定时器


//蓝牙连接句柄，用来保存从机的连接
static unsigned short m_conn_handle = BLE_CONN_HANDLE_INVALID;     


static void timers_init(void);
static void leds_init(void);
static void power_management_init(void);
static void ble_stack_init(void);
static void gap_params_init(void);
static void gatt_init(void);
static void advertising_init(void);
static void conn_params_init(void);
static void advertising_start(void);




//初始化定时器模块
static void timers_init(void)
{
    ret_code_t err_code;
    
    err_code = app_timer_init();   

    APP_ERROR_CHECK(err_code);
	
		
}

//初始化开发板的指示灯
static void leds_init(void)
{
    ret_code_t err_code;
    
    err_code = bsp_init(BSP_INIT_LEDS,NULL); 

    APP_ERROR_CHECK(err_code);
}

//初始化电源管理
static void power_management_init(void)
{
    ret_code_t err_code;

    err_code = nrf_pwr_mgmt_init();  

    APP_ERROR_CHECK(err_code);
}

//BLE事件处理函数
static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
    ret_code_t err_code = NRF_SUCCESS;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_DISCONNECTED:      //连接断开事件
            LOG_OUTPUT("Disconnected.");
        break;

        case BLE_GAP_EVT_CONNECTED:         //连接成功事件
            LOG_OUTPUT("Connected.");
            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);

            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;   //获取连接句柄
       
            err_code = nrf_ble_qwr_conn_handle_assign(&m_qwr, m_conn_handle);  //把连接句柄写入队列
            APP_ERROR_CHECK(err_code);
        break;

        case BLE_GAP_EVT_PHY_UPDATE_REQUEST:   //物理层更新事件
        {
            LOG_OUTPUT("PHY update request.");
            ble_gap_phys_t const phys =
            {
                .rx_phys = BLE_GAP_PHY_AUTO,
                .tx_phys = BLE_GAP_PHY_AUTO,
            };

            err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
            APP_ERROR_CHECK(err_code);
        } break;

        case BLE_GATTC_EVT_TIMEOUT:      //GATT客户端超时事件
            LOG_OUTPUT("GATT Client Timeout.");

            //断开当前连接
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle,
            BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
        break;

        case BLE_GATTS_EVT_TIMEOUT:     //GATT服务器超时事件
            LOG_OUTPUT("GATT Server Timeout.");

            //断开当前连接
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle,
            BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
        break;

        default:
        break;
    }
}

//BLE协议栈初始化
static void ble_stack_init(void)
{
    ret_code_t err_code;

    if(!nrf_sdh_is_enabled())    //如果还没有使能协议栈
    {
        //请求使能协议栈，并在这个函数里面初始化时钟
        err_code = nrf_sdh_enable_request();
        APP_ERROR_CHECK(err_code);
    }

    //使用默认参数配置协议栈，并且把内存的起始地址告诉协议栈
    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);

    //使能协议栈
    err_code = nrf_sdh_ble_enable(&ram_start);
    APP_ERROR_CHECK(err_code);

		//LOG_OUTPUT(">>> softdevice ram_start address is 0x%X >>>",ram_start);
		
    //注册协议栈事件的回调函数
    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}

//GAP参数配置，包括设备名称，外观特征参数，首选连接参数
static void gap_params_init(void)
{
    ret_code_t err_code;

    ble_gap_conn_params_t   gap_conn_params;   //连接参数
    ble_gap_conn_sec_mode_t sec_mode;           //安全模式

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);     //设置为开放连接模式

//    const unsigned char device_name[21] = {0xE5,0xBE,0xAE,0xE8,0x81,0x94,0xE6,0x99,0xBA,0xE6,   \
//                                         0x8E,0xA7,0xE5,0xB7,0xA5,0xE4,0xBD,0x9C,0xE5,0xAE,0xA4};       //中文设备名称
//    err_code = sd_ble_gap_device_name_set(&sec_mode,device_name,sizeof(device_name));

    err_code = sd_ble_gap_device_name_set(&sec_mode,(const uint8_t *)DEVICE_NAME,strlen(DEVICE_NAME));   //设置设备名称

    APP_ERROR_CHECK(err_code);

    /*设置首选连接参数*/
    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;   
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);  //把参数写入协议栈
    APP_ERROR_CHECK(err_code);
    
}

//初始化   GATT模块
static void gatt_init(void)
{
    ret_code_t err_code;

    err_code = nrf_ble_gatt_init(&m_gatt, NULL);

    APP_ERROR_CHECK(err_code);
}

//广播事件处理函数
static void on_adv_evt(ble_adv_evt_t ble_adv_evt)
{
    ret_code_t err_code;

    switch(ble_adv_evt)
    {
        case BLE_ADV_EVT_FAST:    //快速广播事件
            LOG_OUTPUT("Fast advertising.");
            err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
            APP_ERROR_CHECK(err_code);
        break;

        case BLE_ADV_EVT_IDLE:    //快速广播超时事件
            LOG_OUTPUT("Fast advertising timeout");
            err_code = bsp_indication_set(BSP_INDICATE_IDLE);
            APP_ERROR_CHECK(err_code);
        break;

        default:
        break; 
    }
}

//广播地址初始化
static void advertising_address_init(void)
{
    uint32_t err_code;
#if (CURRENT_TEST == RANDOM_STATIC_TEST)       //随机静态地址实验
    static ble_gap_addr_t my_ble_addr;

    /*设置BLE设备随机静态地址*/
    my_ble_addr.addr_type = BLE_GAP_ADDR_TYPE_RANDOM_STATIC;     //地址类型设置为随机静态地址
    my_ble_addr.addr[0] = 0x12;
    my_ble_addr.addr[1] = 0x34;
    my_ble_addr.addr[2] = 0x56;
    my_ble_addr.addr[3] = 0x78;
    my_ble_addr.addr[4] = 0x9a;
    my_ble_addr.addr[5] = 0xCC;   //最高两位必须为1，其他位不能同时为0或同时为1

    err_code = sd_ble_gap_addr_set(&my_ble_addr);

    if(err_code != NRF_SUCCESS)LOG_OUTPUT(">>> set random static address fail >>>");

    /*读出BLE设备地址和地址类型*/
    memset(my_ble_addr.addr,0x00,sizeof(my_ble_addr.addr));
    err_code = sd_ble_gap_addr_get(&my_ble_addr);
    if(err_code == NRF_SUCCESS)
    {
        LOG_OUTPUT(">>> get random static address success >>>");
        LOG_OUTPUT("BLE Address Type: 0x%02X",my_ble_addr.addr_type);    //打印出地址类型
				LOG_OUTPUT("BLE Address: %02X:%02X:%02X:%02X:%02X:%02X",my_ble_addr.addr[0], my_ble_addr.addr[1], my_ble_addr.addr[2], \
															my_ble_addr.addr[3],my_ble_addr.addr[4], my_ble_addr.addr[5]);   
    }
    else
    {
        LOG_OUTPUT(">>> get random static address fail >>>");
    }

#elif(CURRENT_TEST == RANDOM_PRIVATE_TEST)   //私有地址实验
    static ble_gap_privacy_params_t  my_addr = {0};

    my_addr.privacy_mode = BLE_GAP_PRIVACY_MODE_DEVICE_PRIVACY;          
    my_addr.private_addr_type = BLE_GAP_ADDR_TYPE_RANDOM_PRIVATE_NON_RESOLVABLE;   //设置为不可解析私有地址
    //my_addr.private_addr_type = BLE_GAP_ADDR_TYPE_RANDOM_PRIVATE_RESOLVABLE;     //设置为可解析私有地址 
    my_addr.private_addr_cycle_s = 15;     //循环周期15秒，蓝牙核心规范建议15分钟，这里15秒是为了演示方便
    my_addr.p_device_irk = NULL;

    err_code = sd_ble_gap_privacy_set(&my_addr);

    if(err_code != NRF_SUCCESS)
    {
        LOG_OUTPUT(">>> set random private address fail >>>");
    }
#endif
}



//广播初始化
static void advertising_init(void)
{
    ret_code_t err_code;
    ble_advertising_init_t init;

    memset(&init, 0, sizeof(init));   //先清零广播配置参数

    //init.advdata.name_type               = BLE_ADVDATA_NO_NAME;       //没有广播设备名称
    init.advdata.name_type               = BLE_ADVDATA_FULL_NAME;     //全名称广播
    //init.advdata.name_type               = BLE_ADVDATA_SHORT_NAME;    //短设备名称广播
    //init.advdata.short_name_len          = 8;
	  init.advdata.include_appearance      = false;                        //不包含广播外观值
    init.advdata.flags                   = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;   //一般可发现模式
    init.config.ble_adv_fast_enabled     = true;     //设置为快速广播
    init.config.ble_adv_fast_interval    = ADV_FAST_INTERVAL;     //快速广播的间隔
    init.config.ble_adv_fast_timeout     = ADV_FAST_DURATION;     //快速广播的持续时间
    init.evt_handler = on_adv_evt;        //广播事件的回调函数

    signed char tx_power = 40; 
    init.advdata.p_tx_power_level = &tx_power;   //设置发射功率等级

    //UUID服务数组，添加到广播数据中
    static ble_uuid_t advertise_uuids[] = 
    {
        {BLE_UUID_UART_SERVICE, UART_SERVICE_UUID_TYPE}
    };

		init.srdata.uuids_complete.uuid_cnt = sizeof(advertise_uuids) / sizeof(advertise_uuids[0]);    //UUID服务全部包含在扫描回应包里面
    init.srdata.uuids_complete.p_uuids  = advertise_uuids;
		
    //init.advdata.uuids_complete.uuid_cnt = sizeof(advertise_uuids) / sizeof(advertise_uuids[0]);    //UUID服务全部包含在广播数据中
    //init.advdata.uuids_complete.p_uuids  = advertise_uuids;

    //init.advdata.uuids_more_available.uuid_cnt = (sizeof(advertise_uuids) / sizeof(advertise_uuids[0]))-1;   //UUID服务部分包含在广播数据中
    //init.advdata.uuids_more_available.p_uuids  = advertise_uuids;
		
    #if (CURRENT_TEST == SERVICE_DATA_TEST)
    ble_advdata_service_data_t service_data;      
    unsigned char battery_data = 60;    //电池电量，这个电量值是虚拟的
    
    service_data.service_uuid = BLE_UUID_BATTERY_SERVICE;    //电池电量服务 
    service_data.data.size = sizeof(battery_data);           //服务的数据长度
    service_data.data.p_data = &battery_data;                //数据的具体内容

    init.advdata.p_service_data_array = &service_data;       //在广播中添加服务数据 
    init.advdata.service_data_count = 1;                     //数据的数量
    #endif

    #if (CURRENT_TEST == CONNECT_SLAVE_TEST)
    ble_advdata_conn_int_t conn_range;   //从机设备连接参数

    conn_range.min_conn_interval = 30;     //最小连接间隔
    conn_range.max_conn_interval = 100;    //最大连接间隔
    
    init.advdata.p_slave_conn_int = &conn_range;    //广播数据中包含连接间隔
    #endif

    #if (CURRENT_TEST == MANUFACTURER_DATA_TEST)
    unsigned char adv_manuf_data[5] = {0x12,0x34,0x56,0x78,0x9A};   //自定义数据
    ble_advdata_manuf_data_t manuf_specific_data;                   //厂商自定义数据结构体

    manuf_specific_data.company_identifier = 0x0059;                //制造商   ID
    manuf_specific_data.data.p_data = adv_manuf_data;               //制造商自定义的数据内容
    manuf_specific_data.data.size   = sizeof(adv_manuf_data);       //自定义的数据长度 

    init.advdata.p_manuf_specific_data    = &manuf_specific_data;   //广播中加入厂商自定义数据
    #endif

    err_code = ble_advertising_init(&m_advertising, &init);    //根据参数初始化广播
    APP_ERROR_CHECK(err_code);

    ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);  //配置广播标记，默认数值为1

    advertising_address_init();
    
}

//QWR队列事件错误处理
static void nrf_qwr_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}

//串口透传事件回调函数
static void ble_uart_data_handler(ble_uart_evt_t * p_evt)
{
    if(p_evt->type == BLE_UART_EVT_RX_DATA)    //接收到数据事件
    {
        uint32_t err_code;

        for (uint32_t i = 0; i < p_evt->params.rx_data.length; i++)
        {
            do
            {
                err_code = app_uart_put(p_evt->params.rx_data.p_data[i]);
                if ((err_code != NRF_SUCCESS) && (err_code != NRF_ERROR_BUSY))
                {
                    NRF_LOG_ERROR("Failed receiving NUS message. Error 0x%x. ", err_code);
                    APP_ERROR_CHECK(err_code);
                }
            } while (err_code == NRF_ERROR_BUSY);
        }
        if (p_evt->params.rx_data.p_data[p_evt->params.rx_data.length - 1] == '\r')
        {
            while (app_uart_put('\n') == NRF_ERROR_BUSY);
        }
    }

    if (p_evt->type == BLE_UART_EVT_TX_RDY)    //发送就绪事件
    {
			//nrf_gpio_pin_toggle(LED_4);
		}
}

//服务初始化函数
static void services_init(void)
{
    ret_code_t         err_code;
	  ble_uart_init_t     uart_init;   //BLE串口初始化结构体
	
    //初始化队列写入模块
    nrf_ble_qwr_init_t qwr_init = {0};

    qwr_init.error_handler = nrf_qwr_error_handler;
    err_code = nrf_ble_qwr_init(&m_qwr, &qwr_init);
    APP_ERROR_CHECK(err_code);

    //在这里添加串口透传服务
		memset(&uart_init, 0, sizeof(uart_init));
    uart_init.data_handler = ble_uart_data_handler;
    err_code = ble_uart_init(&m_uart, &uart_init);
    APP_ERROR_CHECK(err_code);
		
}

//连接参数协商事件处理函数
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    ret_code_t err_code;

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)    //连接参数协商失败，断开连接
    {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_SUCCEEDED)    //连接参数协商成功
    {

    }
}

//连接参数协商错误
static void conn_params_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}

//连接参数协商初始化
static void conn_params_init(void)
{
    ret_code_t             err_code;
    ble_conn_params_init_t cp_init;

    memset(&cp_init, 0, sizeof(cp_init));    //先清空配置参数

    cp_init.p_conn_params                  = NULL;       //设置为   NULL，表示从主机那里获取连接参数
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;     //首次连接参数更新的延时时间
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;      //以后每次连接参数更新的时间
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;       //尝试连接参数协商的最大次数，超过此次数就放弃连接参数协商
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;            //从连接事件开始计时
    cp_init.disconnect_on_fail             = false;                              //参数更新失败的时候，不会断开蓝牙连接
    cp_init.evt_handler                    = on_conn_params_evt;                 //连接参数更新事件
    cp_init.error_handler                  = conn_params_error_handler;          //连接参数更新错误事件

    err_code = ble_conn_params_init(&cp_init);              //初始化连接参数更新的模块
    APP_ERROR_CHECK(err_code);
}

//启动广播
static void advertising_start(void)
{
    ret_code_t err_code;

    err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);

    APP_ERROR_CHECK(err_code);
}



//BLE相关接口函数初始化
void ble_api_init(void)
{
    timers_init();                    //定时器初始化

    leds_init();                      //指示灯初始化

    power_management_init();          //电源管理初始化

    ble_stack_init();                 //BLE协议栈初始化
 
    gap_params_init();                //GAP参数初始化

    gatt_init();                      //GATT服务初始化

		services_init();                  //BLE服务初始化
	
    advertising_init();               //广播初始化
   
    conn_params_init();               //蓝牙连接参数初始化
  
    advertising_start();              //启动广播   
}

unsigned int ble_send_data(unsigned char *p_data, unsigned short int length)
{
		return ble_uart_data_send(&m_uart, p_data, &length, m_conn_handle);
}
