#ifndef _APP_TIMER_API_H_
#define _APP_TIMER_API_H_


#define APP_TIMER_TOGGLE_INTERVAL         APP_TIMER_TICKS(100) 


extern void my_app_timer_create(void);
extern void my_app_timer_start(void);
extern void my_app_timer_stop(void);
#endif


