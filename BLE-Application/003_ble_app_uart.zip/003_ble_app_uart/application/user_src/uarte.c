#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "app_error.h"
#include "uarte.h"
#include "my_ble_uart.h"
#include "log_debug.h"
#include "ble_api.h"

static uint16_t   m_ble_uarts_max_data_len = BLE_GATT_ATT_MTU_DEFAULT - 3;

static void uart_event_handler(app_uart_evt_t * p_event)
{
		static uint8_t data_array[BLE_UART_MAX_DATA_LEN];
    static uint8_t index = 0;
		uint32_t       err_code;
	
    switch(p_event->evt_type)
    {
        /*An event indicating that UART data has been received. The data is available in the FIFO and can be fetched using @ref app_uart_get*/
        case APP_UART_DATA_READY:
        {
            UNUSED_VARIABLE(app_uart_get(&data_array[index]));
            index++;
            //���մ������ݣ������յ����ݳ��ȴﵽm_ble_uarts_max_data_len���߽��յ����з�����Ϊһ�����ݽ������
            if ((data_array[index - 1] == '\n') || (data_array[index - 1] == '\r') || (index >= m_ble_uarts_max_data_len))
            {
                if (index > 1)
                {
                    NRF_LOG_DEBUG("Ready to send data over BLE NUS");
                    NRF_LOG_HEXDUMP_DEBUG(data_array, index);
                    //���ڽ��յ�����ʹ��notify���͸�BLE����
                    do
                    {
                        uint16_t length = (uint16_t)index;
											
                        err_code = ble_send_data(data_array, length);
											
                        if ((err_code != NRF_ERROR_INVALID_STATE) &&
                            (err_code != NRF_ERROR_RESOURCES) &&
                            (err_code != NRF_ERROR_NOT_FOUND))
                        {
                            APP_ERROR_CHECK(err_code);
                        }
                    } while (err_code == NRF_ERROR_RESOURCES);
                }

                index = 0;
            }
        }
        break;

        /*An error in the FIFO module used by the app_uart module has occured. The FIFO error code is stored in app_uart_evt_t.data.error_code field*/
        case APP_UART_FIFO_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_code);
        break;

        /*An communication error has occured during reception. The error is stored in app_uart_evt_t.data.error_communication field */
        case APP_UART_COMMUNICATION_ERROR:
            //APP_ERROR_HANDLER(p_event->data.error_communication);
        break;

        /*An event indicating that UART has completed transmission of all available data in the TX FIFO */
        case APP_UART_TX_EMPTY:
        break;

        /*An event indicating that UART data has been received, and data is present in data field. This event is only used when no FIFO is configured */
        case APP_UART_DATA:
        break;
        
        default:break;
    }
}

void my_uart_init(void)
{
    uint32_t err_code;

    const app_uart_comm_params_t comm_params = {
          RX_PIN_NUMBER,TX_PIN_NUMBER,
          RTS_PIN_NUMBER,CTS_PIN_NUMBER,
          UART_HWFC,false,NRF_UARTE_BAUDRATE_115200
      };

    APP_UART_FIFO_INIT(&comm_params,UART_RX_BUF_SIZE,UART_TX_BUF_SIZE, \
                         uart_event_handler,APP_IRQ_PRIORITY_LOWEST,err_code);

    APP_ERROR_CHECK(err_code);
}

