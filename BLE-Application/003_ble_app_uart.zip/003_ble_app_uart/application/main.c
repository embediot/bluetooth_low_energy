#include <stdbool.h>
#include <stdint.h>
#include "log_debug.h"
#include "ble_api.h"
#include "nrf_pwr_mgmt.h"
#include "uarte.h"

static void idle_state_handle(void)
{
    if(NRF_LOG_PROCESS() == false)    
    {
        nrf_pwr_mgmt_run();           
    }
}

int main(void)
{
    log_debug_init();      

    LOG_OUTPUT(">>> ble_app_uart template started >>> %s >>>", "helloworld");
	
		my_uart_init();
    ble_api_init();     
     
    while (true)
    {
        idle_state_handle();   
    }
}




