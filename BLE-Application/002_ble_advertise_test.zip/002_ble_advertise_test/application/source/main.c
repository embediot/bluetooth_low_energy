#include <stdbool.h>
#include <stdint.h>
#include "log_debug.h"
#include "ble_api.h"
#include "nrf_pwr_mgmt.h"


//空闲状态处理
static void idle_state_handle(void)
{
    if(NRF_LOG_PROCESS() == false)     //当没有信息需要打印的时候
    {
        nrf_pwr_mgmt_run();            //进行电源管理
    }
}

int main(void)
{
    log_debug_init();      //初始化   log 打印模块

    LOG_OUTPUT(">>> ble_app_template started >>> %s >>>", "helloworld");

    ble_api_init();       //BLE接口初始化
     
    while (true)
    {
        idle_state_handle();    //空闲状态处理
    }
}




