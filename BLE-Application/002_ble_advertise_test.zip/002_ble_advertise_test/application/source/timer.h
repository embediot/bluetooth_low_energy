#ifndef __TIMER_H_
#define __TIMER_H_

#define TIMER_TEST            0x01
#define COUNTER_TEST          0x02
#define CURRENT_TEST_FUNC     COUNTER_TEST

#if (CURRENT_TEST_FUNC == TIMER_TEST)

extern void my_timer_init(void);
extern void my_timer_start(void);
extern void my_timer_stop(void);

#elif (CURRENT_TEST_FUNC == COUNTER_TEST)

extern void my_timer_init(void);
extern void my_timer_start(void);
extern void my_timer_stop(void);
extern void my_timer_increment(void);
extern unsigned int my_timer_capture(void);

#endif

#endif
