#ifndef __GPIOTE_H_
#define __GPIOTE_H_

#define  GPIOTE_TASK_OUTPUT   0x01
#define  GPIOTE_EVENT_INPUT   0x02
#define  GPIOTE_PORT_INPUT    0x03

//#define  CURRENT_TEST         GPIOTE_TASK_OUTPUT
//#define  CURRENT_TEST         GPIOTE_EVENT_INPUT
#define  CURRENT_TEST         GPIOTE_PORT_INPUT

#if (CURRENT_TEST == GPIOTE_TASK_OUTPUT)
#define GPIOTE_TASK_GPIO_OUTPUT    
#endif

extern void gpiote_task_test();
extern void my_gpiote_init(void);

#endif

