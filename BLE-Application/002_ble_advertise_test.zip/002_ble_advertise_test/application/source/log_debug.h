#ifndef __LOG_DEBUG_H_
#define __LOG_DEBUG_H_

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#define LOG_OUTPUT(...)        NRF_LOG_INFO(__VA_ARGS__)

extern void log_debug_init(void);

#endif

